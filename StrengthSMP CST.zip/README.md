# StrengthSMP Plugin

Plugin Paper/Spigot (**1.21.x**) ispirato a **StrengthSMP**: ogni uccisione PvP ti rende più forte,
ogni morte ti indebolisce. Ogni giocatore sblocca inoltre casualmente una **classe arma** (Spada,
Ascia, Scudo, Tridente o Arco) e può usare **solo** le abilità speciali di quella classe.

## Meccaniche implementate

### Strength
- Si parte sempre con **0 di Strength** al primo ingresso nel mondo.
- **Guadagno/perdita**: uccidi un giocatore → +1 Strength (configurabile). Muori (per mano di
  un giocatore, per mob o per ambiente) → -1 Strength (configurabile,
  `strength.only-pvp-affects-strength: false` di default). Min **-5**, max **5** (configurabili).
- **Il danno scala moltiplicativamente con la Strength**: danno finale = danno base ×
  `(1 + 0.1 × Strength)`. Con Strength 5 il danno è ×1,5; con Strength 4 è ×1,4; con
  Strength -1 è ×0,9; e così via (il moltiplicatore per punto è configurabile).
- **Strength Token**: oggetto craftabile (diamanti + polvere di blaze + Nether Star, ricetta
  configurabile) che, usato con click destro, dà +1 Strength permanente.
- **Eliminazione per Strength negativa**: se la Strength scende a -5, il giocatore va
  automaticamente in modalità spettatore finché qualcuno non lo rianima con
  `/revive <player>` consumando uno **Strength Token**. Le rianimazioni sono **illimitate**:
  non esiste più alcun sistema di "vite".
- **Prelievo (`/withdraw <amount>`)**: converte `<amount>` punti della tua Strength in
  altrettanti **Strength Token** fisici, consegnati in mano (o nell'inventario se la mano
  è occupata). Es: hai 4 Strength, `/withdraw 1` → resti con 3 Strength e ricevi 1 Strength
  Token. Non puoi scendere sotto `strength.min-strength`.

### Classi arma (Spada / Ascia / Scudo / Tridente / Arco)
Al **primo ingresso** nel server, ogni giocatore riceve **una classe casuale** tra queste
cinque. Può usare **solo** le abilità speciali e i potenziamenti dell'arma corrispondente:
tutte le altre armi funzionano come in vanilla per lui/lei (nessun bonus, nessun malus).

Puoi controllare la tua classe con `/strength class`.

- **Token del Destino**: oggetto craftabile con **diamanti + lingotti di netherite** (ricetta
  configurabile). Usato con click destro, sostituisce la classe attuale con una nuova classe
  casuale (diversa dalla precedente), mantenendo solo le abilità della nuova classe.

Ogni abilità **attivabile** (Shift + click destro) ha una **ricarica uniforme di 45 secondi**
(configurabile in `abilities.cooldown-seconds`).

#### Spada
Dopo una combo di **5 colpi consecutivi** (non interrotta da una pausa troppo lunga),
Shift + click destro attiva **"Furia della Lama"**: una seconda spada compare
temporaneamente nella mano secondaria e tutti i colpi (anche quelli normali) diventano
critici per 15 secondi.

#### Ascia
Ogni **3 colpi** blocca movimento e visuale del nemico per 1 secondo. Shift + click destro
attiva **"Furia del Boscaiolo"**: i colpi critici fanno il doppio del danno per 10 secondi.

#### Scudo
- Mentre impugni uno scudo (mano principale o secondaria) perdi **2 cuori** di vita massima
  (4 HP), come compensazione per la protezione che offre.
- Se un avversario **disattiva** il tuo scudo (tipicamente colpendolo con un'ascia mentre
  para), per gli **8 secondi** successivi subisci **metà danno**, come contropartita.
- Shift + click destro (scudo in mano principale) attiva **"Aegis Infrangibile"**: sei
  **immortale** per 10 secondi, ma per tutta la durata hai **Lentezza II**.

#### Tridente (vanilla)
Non c'è più una "Lancia" con ricetta personalizzata: si usa il **Tridente vanilla**.
- Ogni **2 colpi** (sia in mischia col Tridente equipaggiato, sia lanciandolo) scaglia
  **1 fulmine** (solo effetto visivo/sonoro + danno diretto, senza incendiare nulla) sul
  bersaglio colpito.
- Shift + click destro (senza lanciarlo) attiva **"Ira di Nettuno"**: scaglia fino a 5
  fulmini sui nemici entro un raggio di 6 blocchi, infliggendo danno e rallentandoli per
  5 secondi. Colpisce solo entità vive diverse da te.

#### Arco
- **Passiva "Freccia Esplosiva"**: dopo **3 colpi consecutivi a segno** (una freccia mancata
  interrompe la serie), la freccia **successiva esplode** all'impatto: infligge danno ad area
  ai nemici vicini **senza danneggiare i blocchi** (nessuna vera esplosione, solo
  particelle/suono + danno diretto).
- **Abilità speciale "Pioggia di Frecce"** (automatica): dopo **5 colpi consecutivi senza
  mancare E senza essere colpiti** (se l'arciere subisce danno la serie si azzera), scatena
  **20 frecce** che cadono dall'alto sul nemico, sparse **a cerchio** attorno a lui (non tutte
  precise su un unico blocco). Ricarica 45s (convenzione generale).

#### Tridente — Scatto (movimento)
Oltre a "Ira di Nettuno", il Tridente ha anche uno **Scatto**: Shift + tasto di scambio mano
(F di default) lancia il giocatore in avanti (stesso effetto della vecchia "Lancia"). Ha una
ricarica **fissa di 20 secondi**, indipendente dalla ricarica generale di 45s delle altre
abilità, perché è pensato come una mossa di mobilità da poter usare più spesso.

### Altre meccaniche
- **Mazza**: dopo un colpo va in ricarica per **60 secondi** (non fa parte del sistema di
  classi: si applica a chiunque la usi).
- **Kill in stealth**: se uccidi qualcuno mentre sei invisibile, il tuo nome non compare né
  nel messaggio di morte né nell'annuncio pubblico della kill.
- **Totem Limiter**: limita quanti Totem di Immortalità un giocatore può portare addosso
  (inventario, click, drag), per evitare PvP infiniti.
- **Persistenza dati**: tutto salvato in `plugins/StrengthSMP/data.yml` (Strength, kills,
  morti, stato eliminato, classe arma).

## Comandi

| Comando | Permesso | Descrizione |
|---|---|---|
| `/strength get [player]` | `strengthsmp.use` | Mostra la Strength (tua o di un altro) e il moltiplicatore di danno |
| `/strength class` | `strengthsmp.use` | Mostra la tua classe arma attuale |
| `/strength top` | `strengthsmp.use` | Classifica dei 10 più forti |
| `/strength set <player> <val>` | `strengthsmp.admin` | Imposta la Strength di un giocatore |
| `/strength reset <player>` | `strengthsmp.admin` | Resetta la Strength di un giocatore |
| `/strength help` | - | Mostra l'aiuto |
| `/revive <player>` | `strengthsmp.revive` | Rianima un eliminato (serve uno Strength Token in mano) |
| `/withdraw <amount>` | `strengthsmp.use` | Converte `<amount>` Strength in altrettanti Strength Token in mano |

Alias: `/str`, `/forza`, `/rianima`, `/preleva`

## Note di design

- **Attivazione abilità**: Shift + click destro con l'arma della propria classe in mano
  (per il Tridente questo sostituisce/annulla il lancio vanilla solo quando sei accovacciato:
  se non sei accovacciato, il Tridente si lancia normalmente e il colpo conta comunque ai
  fini del contatore "ogni 2 colpi"). Lo **Scatto** del Tridente usa invece Shift + tasto di
  scambio mano (F), per non entrare in conflitto con "Ira di Nettuno".
- **Blocco della visuale** dell'ascia: essendo un plugin server-side non può disattivare la
  telecamera del client, ma annullare il movimento del colpito riporta anche al suo
  orientamento precedente, dando di fatto l'effetto di visuale bloccata.
- **Immortalità dello Scudo**: implementata con `Player#setInvulnerable(true)` per la durata
  configurata, così da annullare qualunque tipo di danno (non solo quello da altri giocatori).
- **Gating per classe**: ogni controllo di abilità/potenziamento passa da
  `PlayerDataManager#isClass(player, PlayerClass.X)`, così un giocatore che non ha sbloccato
  una certa classe usa quell'arma in modo puramente vanilla (nessun bonus, nessun malus).

## Configurazione

Tutto è personalizzabile in `config.yml`: valori di guadagno/perdita di Strength, moltiplicatore
di danno, ricetta dello Strength Token e del Token del Destino, eliminazione/rianimazione,
abilità delle 5 classi arma (durate, danni, raggi, messaggi), ricarica unificata delle abilità,
limite totem, messaggi.

## Come compilare

Richiede l'API di **Paper 1.21.11** (compatibile con la linea 1.21.x; usa `Material.MACE`,
aggiunto in Minecraft 1.21). Serve **Java 17+** e **Maven**, con connessione a internet
per scaricare le dipendenze Paper (repo `repo.papermc.io`):

```bash
cd StrengthSMP
mvn clean package
```

Il jar compilato apparirà in `target/StrengthSMP-1.0.0.jar`. Mettilo nella cartella
`plugins/` del tuo server Paper/Spigot 1.21.x e riavvia.

> Nota: non ho potuto compilare il `.jar` qui perché questo ambiente non ha accesso
> a internet (serve per scaricare `paper-api` da Maven). Ti passo quindi il codice
> sorgente completo, pronto per essere compilato con `mvn package` sul tuo computer,
> oppure aperto/compilato direttamente in IntelliJ IDEA. Ho verificato manualmente le
> firme dei metodi/API usati (incluse le rinominazioni recenti come
> `PotionEffectType.SLOWNESS` e `io.papermc.paper.event.player.PlayerShieldDisableEvent`
> in Paper 1.21.x), ma ti consiglio comunque un primo `mvn clean package` di verifica.

## Struttura del progetto

```
StrengthSMP/
├── pom.xml
└── src/main/
    ├── java/com/strengthsmp/
    │   ├── StrengthSMPPlugin.java        (classe principale)
    │   ├── commands/
    │   │   ├── StrengthCommand.java
    │   │   ├── ReviveCommand.java        (/revive, rianimazione illimitata con Strength Token)
    │   │   └── WithdrawCommand.java      (/withdraw, converte Strength in Strength Token)
    │   ├── combat/AbilityManager.java    (cooldown, combo, contatori, stati attivi delle armi)
    │   ├── listeners/
    │   │   ├── PvPListener.java          (kill/death → strength, kill in stealth)
    │   │   ├── WeaponAbilityListener.java (abilità Mazza/Spada/Ascia/Scudo/Tridente/Arco)
    │   │   ├── ShieldListener.java       (malus HP scudo, buff su disattivazione scudo)
    │   │   ├── TokenListener.java        (uso Strength Token e Token del Destino)
    │   │   ├── JoinQuitListener.java     (applica/salva dati, assegna classe al 1° ingresso)
    │   │   └── TotemLimiterListener.java
    │   ├── managers/
    │   │   ├── PlayerData.java
    │   │   ├── PlayerDataManager.java    (strength, eliminazione, rianimazione, classe)
    │   │   └── PlayerClass.java          (le 5 classi arma sbloccabili)
    │   └── items/
    │       ├── StrengthToken.java
    │       └── RerollToken.java          (Token del Destino, cambia classe)
    └── resources/
        ├── plugin.yml
        └── config.yml
```
