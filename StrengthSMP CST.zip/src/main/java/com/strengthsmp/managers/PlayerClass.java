package com.strengthsmp.managers;

import java.util.Random;

/**
 * Le 5 "classi" arma sbloccabili. Ogni giocatore ne ha una sola alla volta:
 * può usare SOLO le abilità/potenziamenti dell'arma corrispondente alla
 * propria classe. Viene assegnata casualmente al primo ingresso nel server
 * e può essere ri-sorteggiata con il Token del Destino (diamanti + netherite).
 */
public enum PlayerClass {

    SWORD("Spada", "&d"),
    AXE("Ascia", "&6"),
    SHIELD("Scudo", "&b"),
    TRIDENT("Tridente", "&3"),
    BOW("Arco", "&a");

    private final String displayName;
    private final String color;

    PlayerClass(String displayName, String color) {
        this.displayName = displayName;
        this.color = color;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getColor() {
        return color;
    }

    private static final PlayerClass[] VALUES = values();
    private static final Random RANDOM = new Random();

    public static PlayerClass random() {
        return VALUES[RANDOM.nextInt(VALUES.length)];
    }

    /** Sceglie una classe casuale diversa da quella passata (usata dal reroll). */
    public static PlayerClass randomExcluding(PlayerClass exclude) {
        if (exclude == null || VALUES.length <= 1) return random();
        PlayerClass result;
        do {
            result = random();
        } while (result == exclude);
        return result;
    }
}
