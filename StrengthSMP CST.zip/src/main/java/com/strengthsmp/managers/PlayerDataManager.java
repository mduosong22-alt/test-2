package com.strengthsmp.managers;

import com.strengthsmp.StrengthSMPPlugin;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Gestisce il caricamento, salvataggio e l'applicazione in-game
 * dei dati di Strength/classe di ogni giocatore.
 */
public class PlayerDataManager {

    private final StrengthSMPPlugin plugin;
    private final Map<UUID, PlayerData> cache = new HashMap<>();
    // Giocatori per cui la classe è stata appena assegnata in questo caricamento
    // (usato da JoinQuitListener per mostrare il messaggio di benvenuto una sola volta)
    private final Set<UUID> freshlyAssignedClass = new HashSet<>();
    private final File dataFile;
    private FileConfiguration dataConfig;

    public PlayerDataManager(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
        load();
    }

    private void load() {
        if (!dataFile.exists()) {
            plugin.getDataFolder().mkdirs();
            try {
                dataFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("Impossibile creare data.yml: " + e.getMessage());
            }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);

        if (dataConfig.getConfigurationSection("players") != null) {
            for (String key : dataConfig.getConfigurationSection("players").getKeys(false)) {
                UUID uuid = UUID.fromString(key);
                int strength = dataConfig.getInt("players." + key + ".strength", plugin.getConfig().getInt("strength.starting-strength", 0));
                int kills = dataConfig.getInt("players." + key + ".kills", 0);
                int deaths = dataConfig.getInt("players." + key + ".deaths", 0);
                boolean eliminated = dataConfig.getBoolean("players." + key + ".eliminated", false);
                String classRaw = dataConfig.getString("players." + key + ".class", null);
                PlayerClass playerClass = null;
                if (classRaw != null) {
                    try {
                        playerClass = PlayerClass.valueOf(classRaw);
                    } catch (IllegalArgumentException ignored) {
                        playerClass = null;
                    }
                }
                cache.put(uuid, new PlayerData(uuid, strength, kills, deaths, eliminated, playerClass));
            }
        }
    }

    public void saveAll() {
        for (PlayerData data : cache.values()) {
            String path = "players." + data.getUuid().toString();
            dataConfig.set(path + ".strength", data.getStrength());
            dataConfig.set(path + ".kills", data.getKills());
            dataConfig.set(path + ".deaths", data.getDeaths());
            dataConfig.set(path + ".eliminated", data.isEliminated());
            dataConfig.set(path + ".class", data.getWeaponClass() != null ? data.getWeaponClass().name() : null);
        }
        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Impossibile salvare data.yml: " + e.getMessage());
        }
    }

    /**
     * Recupera (o crea) i dati di un giocatore. Se è la prima volta che si
     * vede questo giocatore, gli viene assegnata una classe casuale tra
     * Spada/Ascia/Scudo/Tridente/Arco (vedi PlayerClass).
     */
    public PlayerData getData(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerData existing = cache.get(uuid);
        if (existing != null) return existing;

        PlayerData data = new PlayerData(
                uuid,
                plugin.getConfig().getInt("strength.starting-strength", 0),
                0, 0
        );
        data.setWeaponClass(PlayerClass.random());
        freshlyAssignedClass.add(uuid);
        cache.put(uuid, data);
        return data;
    }

    public PlayerData getData(UUID uuid) {
        return cache.get(uuid);
    }

    /** True una sola volta, subito dopo il primo ingresso in cui è stata assegnata la classe. */
    public boolean consumeFreshlyAssignedClass(UUID uuid) {
        return freshlyAssignedClass.remove(uuid);
    }

    public PlayerClass getPlayerClass(Player player) {
        return getData(player).getWeaponClass();
    }

    public boolean isClass(Player player, PlayerClass playerClass) {
        return getPlayerClass(player) == playerClass;
    }

    /** Sostituisce la classe attuale con una nuova, casuale e diversa dalla precedente. */
    public PlayerClass rerollClass(Player player) {
        PlayerData data = getData(player);
        PlayerClass newClass = PlayerClass.randomExcluding(data.getWeaponClass());
        data.setWeaponClass(newClass);
        return newClass;
    }

    public int getMinStrength() {
        return plugin.getConfig().getInt("strength.min-strength", -5);
    }

    public int getMaxStrength() {
        return plugin.getConfig().getInt("strength.max-strength", 5);
    }

    /**
     * Modifica la Strength di un giocatore rispettando i limiti min/max,
     * e riapplica subito il moltiplicatore di danno in-game.
     */
    public void addStrength(Player player, int amount) {
        PlayerData data = getData(player);
        int newValue = data.getStrength() + amount;
        newValue = Math.max(getMinStrength(), Math.min(getMaxStrength(), newValue));
        data.setStrength(newValue);
        applyStrengthAttribute(player);
        checkElimination(player);
    }

    public void setStrength(Player player, int amount) {
        PlayerData data = getData(player);
        int clamped = Math.max(getMinStrength(), Math.min(getMaxStrength(), amount));
        data.setStrength(clamped);
        applyStrengthAttribute(player);
        checkElimination(player);
    }

    /**
     * Se la Strength è scesa fino alla soglia di eliminazione, mette il
     * giocatore in modalità spettatore finché non viene rianimato con
     * "/revive <player>" (Nether Star). Le rianimazioni sono illimitate.
     */
    private void checkElimination(Player player) {
        if (!plugin.getConfig().getBoolean("elimination.enabled", true)) return;

        PlayerData data = getData(player);
        int threshold = plugin.getConfig().getInt("elimination.threshold", -5);

        if (data.isEliminated()) return;
        if (data.getStrength() > threshold) return;

        data.setEliminated(true);
        player.setGameMode(GameMode.SPECTATOR);

        String msgPrefix = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", ""));

        String eliminatedMsg = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("elimination.messages.eliminated", ""))
                .replace("%strength%", String.valueOf(data.getStrength()));
        player.sendMessage(msgPrefix + eliminatedMsg);

        String broadcastMsg = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("elimination.messages.eliminated-broadcast", ""))
                .replace("%player%", player.getName());
        plugin.getServer().broadcastMessage(msgPrefix + broadcastMsg);
    }

    /**
     * Rianima un giocatore eliminato: lo riporta in sopravvivenza e gli
     * assegna la Strength di rianimazione configurata. Può essere fatto
     * un numero illimitato di volte.
     */
    public void revive(Player player) {
        PlayerData data = getData(player);
        data.setEliminated(false);

        int reviveStrength = plugin.getConfig().getInt("elimination.revive-strength", 0);
        int clamped = Math.max(getMinStrength(), Math.min(getMaxStrength(), reviveStrength));
        data.setStrength(clamped);

        player.setGameMode(GameMode.SURVIVAL);
        applyStrengthAttribute(player);

        player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation().add(0, 1, 0), 40, 0.5, 1, 0.5, 0.1);
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 1f, 1f);
    }

    /**
     * Applica il moltiplicatore di danno in attacco in base alla Strength attuale:
     * danno finale = danno_base * (1 + moltiplicatore-per-punto * strength).
     * Con max-strength = 5 e moltiplicatore-per-punto = 0.1 di default:
     * Strength 5 => x1.5, Strength 4 => x1.4, Strength -1 => x0.9, ecc.
     * Usa un AttributeModifier ADD_SCALAR con chiave fissa così da poterlo
     * rimuovere/riapplicare senza duplicare bonus.
     */
    public void applyStrengthAttribute(Player player) {
        AttributeInstance attackDamage = player.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE);
        if (attackDamage == null) return;

        // Rimuove eventuali modificatori precedenti applicati da questo plugin
        attackDamage.getModifiers().stream()
                .filter(mod -> mod.getName().equals("strengthsmp_bonus"))
                .forEach(attackDamage::removeModifier);

        double multiplierPerPoint = plugin.getConfig().getDouble("strength.damage-multiplier-per-point", 0.1);
        int strength = getData(player).getStrength();
        double scalar = strength * multiplierPerPoint;

        if (scalar != 0) {
            AttributeModifier modifier = new AttributeModifier(
                    UUID.nameUUIDFromBytes(("strengthsmp_bonus_" + player.getUniqueId()).getBytes()),
                    "strengthsmp_bonus",
                    scalar,
                    AttributeModifier.Operation.ADD_SCALAR
            );
            attackDamage.addModifier(modifier);
        }
    }

    /** Il moltiplicatore di danno attualmente attivo per un giocatore (utile per messaggi/debug). */
    public double getDamageMultiplier(Player player) {
        double multiplierPerPoint = plugin.getConfig().getDouble("strength.damage-multiplier-per-point", 0.1);
        int strength = getData(player).getStrength();
        return 1.0 + (strength * multiplierPerPoint);
    }

    public Map<UUID, PlayerData> getAllCachedData() {
        return cache;
    }
}
