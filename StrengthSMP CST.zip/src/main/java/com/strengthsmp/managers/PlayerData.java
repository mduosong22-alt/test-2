package com.strengthsmp.managers;

import java.util.UUID;

public class PlayerData {

    private final UUID uuid;
    private int strength;
    private int kills;
    private int deaths;
    private boolean eliminated;
    private PlayerClass weaponClass;

    public PlayerData(UUID uuid, int strength, int kills, int deaths) {
        this(uuid, strength, kills, deaths, false, null);
    }

    public PlayerData(UUID uuid, int strength, int kills, int deaths, boolean eliminated, PlayerClass weaponClass) {
        this.uuid = uuid;
        this.strength = strength;
        this.kills = kills;
        this.deaths = deaths;
        this.eliminated = eliminated;
        this.weaponClass = weaponClass;
    }

    public UUID getUuid() {
        return uuid;
    }

    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public int getKills() {
        return kills;
    }

    public void incrementKills() {
        this.kills++;
    }

    public int getDeaths() {
        return deaths;
    }

    public void incrementDeaths() {
        this.deaths++;
    }

    public boolean isEliminated() {
        return eliminated;
    }

    public void setEliminated(boolean eliminated) {
        this.eliminated = eliminated;
    }

    public PlayerClass getWeaponClass() {
        return weaponClass;
    }

    public void setWeaponClass(PlayerClass weaponClass) {
        this.weaponClass = weaponClass;
    }
}
