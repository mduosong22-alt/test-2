package com.strengthsmp.combat;

import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Tiene traccia, in memoria (non serve persistenza su disco), di tutti gli
 * stati temporanei legati alle abilità delle armi: cooldown, combo,
 * buff attivi e stati speciali (congelamento, immortalità, ecc).
 */
public class AbilityManager {

    // Cooldown generici per arma/abilità, chiave: "tipo:uuid"
    private final Map<String, Long> cooldowns = new HashMap<>();

    // ---------- Spada ----------
    private final Map<UUID, Integer> swordComboCount = new HashMap<>();
    private final Map<UUID, Long> swordComboLastHit = new HashMap<>();
    private final Map<UUID, Boolean> swordComboReady = new HashMap<>();
    private final Map<UUID, Long> swordCritActiveUntil = new HashMap<>();
    private final Map<UUID, ItemStack> swordSavedOffhand = new HashMap<>();

    // ---------- Ascia ----------
    private final Map<UUID, Integer> axeHitCounter = new HashMap<>();
    private final Map<UUID, Long> axeDoubleCritUntil = new HashMap<>();

    // Congelamento (vittima colpita dall'ascia)
    private final Map<UUID, Long> frozenUntil = new HashMap<>();

    // ---------- Arco ----------
    private final Map<UUID, Integer> bowHitStreak = new HashMap<>();
    private final Map<UUID, Boolean> bowExplosiveReady = new HashMap<>();
    // Serie separata per l'abilità "Pioggia di Frecce": si interrompe anche
    // se l'arciere viene colpito (non solo se manca un colpo)
    private final Map<UUID, Integer> bowRainStreak = new HashMap<>();

    // ---------- Tridente ----------
    private final Map<UUID, Integer> tridentHitCounter = new HashMap<>();

    // ---------- Scudo ----------
    private final Map<UUID, Long> shieldHalfDamageUntil = new HashMap<>();
    private final Map<UUID, Long> shieldImmortalUntil = new HashMap<>();

    // ---------- Cooldown generico ----------

    public boolean isOnCooldown(String type, UUID uuid) {
        Long until = cooldowns.get(type + ":" + uuid);
        return until != null && until > System.currentTimeMillis();
    }

    public long getRemainingSeconds(String type, UUID uuid) {
        Long until = cooldowns.get(type + ":" + uuid);
        if (until == null) return 0;
        long remainingMs = until - System.currentTimeMillis();
        return Math.max(0, (remainingMs + 999) / 1000);
    }

    public void setCooldown(String type, UUID uuid, long seconds) {
        cooldowns.put(type + ":" + uuid, System.currentTimeMillis() + (seconds * 1000L));
    }

    public void clearCooldown(String type, UUID uuid) {
        cooldowns.remove(type + ":" + uuid);
    }

    // ---------- Combo spada ----------

    public void registerSwordHit(UUID uuid, long comboTimeoutSeconds) {
        long now = System.currentTimeMillis();
        Long last = swordComboLastHit.get(uuid);
        int count = swordComboCount.getOrDefault(uuid, 0);

        if (last == null || (now - last) > comboTimeoutSeconds * 1000L) {
            count = 1;
        } else {
            count++;
        }
        swordComboLastHit.put(uuid, now);
        swordComboCount.put(uuid, count);
    }

    public int getSwordCombo(UUID uuid) {
        return swordComboCount.getOrDefault(uuid, 0);
    }

    public void resetSwordCombo(UUID uuid) {
        swordComboCount.put(uuid, 0);
        swordComboLastHit.remove(uuid);
    }

    public boolean isSwordComboReady(UUID uuid) {
        return swordComboReady.getOrDefault(uuid, false);
    }

    public void setSwordComboReady(UUID uuid, boolean ready) {
        swordComboReady.put(uuid, ready);
    }

    public boolean isSwordCritActive(UUID uuid) {
        Long until = swordCritActiveUntil.get(uuid);
        return until != null && until > System.currentTimeMillis();
    }

    public void setSwordCritActiveUntil(UUID uuid, long untilMillis) {
        swordCritActiveUntil.put(uuid, untilMillis);
    }

    public void clearSwordCritActive(UUID uuid) {
        swordCritActiveUntil.remove(uuid);
    }

    public void saveOffhand(UUID uuid, ItemStack item) {
        swordSavedOffhand.put(uuid, item);
    }

    public ItemStack takeSavedOffhand(UUID uuid) {
        return swordSavedOffhand.remove(uuid);
    }

    public boolean hasSavedOffhand(UUID uuid) {
        return swordSavedOffhand.containsKey(uuid);
    }

    // ---------- Ascia ----------

    public int incrementAndGetAxeHits(UUID uuid) {
        int next = axeHitCounter.getOrDefault(uuid, 0) + 1;
        axeHitCounter.put(uuid, next);
        return next;
    }

    public void resetAxeHits(UUID uuid) {
        axeHitCounter.put(uuid, 0);
    }

    public boolean isAxeDoubleCritActive(UUID uuid) {
        Long until = axeDoubleCritUntil.get(uuid);
        return until != null && until > System.currentTimeMillis();
    }

    public void setAxeDoubleCritUntil(UUID uuid, long untilMillis) {
        axeDoubleCritUntil.put(uuid, untilMillis);
    }

    // ---------- Congelamento ----------

    public void freeze(UUID uuid, long seconds) {
        frozenUntil.put(uuid, System.currentTimeMillis() + (seconds * 1000L));
    }

    public boolean isFrozen(UUID uuid) {
        Long until = frozenUntil.get(uuid);
        return until != null && until > System.currentTimeMillis();
    }

    // ---------- Arco ----------

    /** Incrementa la serie di colpi consecutivi a segno e la restituisce. */
    public int incrementAndGetBowStreak(UUID uuid) {
        int next = bowHitStreak.getOrDefault(uuid, 0) + 1;
        bowHitStreak.put(uuid, next);
        return next;
    }

    public void resetBowStreak(UUID uuid) {
        bowHitStreak.put(uuid, 0);
    }

    public boolean isBowExplosiveReady(UUID uuid) {
        return bowExplosiveReady.getOrDefault(uuid, false);
    }

    public void setBowExplosiveReady(UUID uuid, boolean ready) {
        bowExplosiveReady.put(uuid, ready);
    }

    /** Incrementa la serie (senza mancare né essere colpiti) per la Pioggia di Frecce. */
    public int incrementAndGetBowRainStreak(UUID uuid) {
        int next = bowRainStreak.getOrDefault(uuid, 0) + 1;
        bowRainStreak.put(uuid, next);
        return next;
    }

    public void resetBowRainStreak(UUID uuid) {
        bowRainStreak.put(uuid, 0);
    }

    // ---------- Tridente ----------

    public int incrementAndGetTridentHits(UUID uuid) {
        int next = tridentHitCounter.getOrDefault(uuid, 0) + 1;
        tridentHitCounter.put(uuid, next);
        return next;
    }

    public void resetTridentHits(UUID uuid) {
        tridentHitCounter.put(uuid, 0);
    }

    // ---------- Scudo ----------

    public void setShieldHalfDamageUntil(UUID uuid, long untilMillis) {
        shieldHalfDamageUntil.put(uuid, untilMillis);
    }

    public boolean isShieldHalfDamageActive(UUID uuid) {
        Long until = shieldHalfDamageUntil.get(uuid);
        return until != null && until > System.currentTimeMillis();
    }

    public void setShieldImmortalUntil(UUID uuid, long untilMillis) {
        shieldImmortalUntil.put(uuid, untilMillis);
    }

    public boolean isShieldImmortalActive(UUID uuid) {
        Long until = shieldImmortalUntil.get(uuid);
        return until != null && until > System.currentTimeMillis();
    }

    // ---------- Pulizia alla disconnessione ----------

    public void clearPlayer(UUID uuid) {
        swordComboCount.remove(uuid);
        swordComboLastHit.remove(uuid);
        swordComboReady.remove(uuid);
        swordCritActiveUntil.remove(uuid);
        axeHitCounter.remove(uuid);
        axeDoubleCritUntil.remove(uuid);
        frozenUntil.remove(uuid);
        bowHitStreak.remove(uuid);
        bowExplosiveReady.remove(uuid);
        bowRainStreak.remove(uuid);
        tridentHitCounter.remove(uuid);
        shieldHalfDamageUntil.remove(uuid);
        shieldImmortalUntil.remove(uuid);
        // I cooldown restano intenzionalmente (evita di aggirarli con relog)
    }
}
