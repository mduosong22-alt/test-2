package com.strengthsmp.items;

import com.strengthsmp.StrengthSMPPlugin;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.Arrays;
import java.util.List;

/**
 * "Token del Destino": craftabile con diamanti e netherite. Usato con click
 * destro, sostituisce la classe arma attuale del giocatore con una nuova
 * classe casuale (diversa dalla precedente), mantenendo solo le abilità
 * della nuova classe.
 */
public class RerollToken {

    private final StrengthSMPPlugin plugin;
    private final NamespacedKey tokenKey;

    public RerollToken(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
        this.tokenKey = new NamespacedKey(plugin, "reroll_token");
    }

    public NamespacedKey getKey() {
        return tokenKey;
    }

    public ItemStack createToken() {
        String name = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("reroll-token.item-name", "&5&lToken del Destino"));

        Material material = Material.matchMaterial(
                plugin.getConfig().getString("reroll-token.material", "NETHERITE_INGOT"));
        if (material == null) material = Material.NETHERITE_INGOT;

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(List.of(
                ChatColor.GRAY + "Clicca con il tasto destro per",
                ChatColor.GRAY + "sbloccare " + ChatColor.LIGHT_PURPLE + "una nuova classe arma casuale" + ChatColor.GRAY + "!",
                ChatColor.DARK_GRAY + "(sostituisce la classe attuale)"
        ));
        meta.getPersistentDataContainer().set(tokenKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isToken(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(tokenKey, PersistentDataType.BYTE);
    }

    /** Registra la ricetta di crafting definita nel config.yml (default: diamanti + netherite). */
    public void registerRecipe() {
        if (!plugin.getConfig().getBoolean("reroll-token.enabled", true)) return;

        ItemStack result = createToken();
        ShapedRecipe recipe = new ShapedRecipe(new NamespacedKey(plugin, "reroll_token_recipe"), result);

        List<String> shape = plugin.getConfig().getStringList("reroll-token.recipe.shape");
        if (shape.size() != 3) {
            shape = Arrays.asList("ABA", "BCB", "ABA");
        }
        recipe.shape(shape.toArray(new String[0]));

        var recipeSection = plugin.getConfig().getConfigurationSection("reroll-token.recipe");
        for (String key : recipeSection.getKeys(false)) {
            if (key.equals("shape")) continue;
            String materialName = recipeSection.getString(key);
            Material material = Material.matchMaterial(materialName);
            if (material != null && key.length() == 1) {
                recipe.setIngredient(key.charAt(0), material);
            }
        }

        plugin.getServer().addRecipe(recipe);
    }
}
