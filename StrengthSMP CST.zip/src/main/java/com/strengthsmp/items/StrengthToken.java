package com.strengthsmp.items;

import com.strengthsmp.StrengthSMPPlugin;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.Arrays;
import java.util.List;

public class StrengthToken {

    private final StrengthSMPPlugin plugin;
    private final NamespacedKey tokenKey;

    public StrengthToken(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
        this.tokenKey = new NamespacedKey(plugin, "strength_token");
    }

    public NamespacedKey getKey() {
        return tokenKey;
    }

    /** Crea l'ItemStack del token, marcato con un tag persistente per riconoscerlo. */
    public ItemStack createToken() {
        String name = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("token.item-name", "&b&lStrength Token"));

        ItemStack item = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        int gain = plugin.getConfig().getInt("token.strength-gain", 1);
        meta.setLore(List.of(
                ChatColor.GRAY + "Clicca con il tasto destro per",
                ChatColor.GRAY + "guadagnare " + ChatColor.AQUA + "+" + gain + " Strength" + ChatColor.GRAY + " permanente."
        ));
        meta.getPersistentDataContainer().set(tokenKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isToken(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(tokenKey, PersistentDataType.BYTE);
    }

    /** Registra la ricetta di crafting definita nel config.yml */
    public void registerRecipe() {
        if (!plugin.getConfig().getBoolean("token.enabled", true)) return;

        ItemStack result = createToken();
        ShapedRecipe recipe = new ShapedRecipe(new NamespacedKey(plugin, "strength_token_recipe"), result);

        List<String> shape = plugin.getConfig().getStringList("token.recipe.shape");
        if (shape.size() != 3) {
            shape = Arrays.asList("ABA", "BCB", "ADA");
        }
        recipe.shape(shape.toArray(new String[0]));

        var recipeSection = plugin.getConfig().getConfigurationSection("token.recipe");
        for (String key : recipeSection.getKeys(false)) {
            if (key.equals("shape")) continue;
            String materialName = recipeSection.getString(key);
            Material material = Material.matchMaterial(materialName);
            if (material != null && key.length() == 1) {
                recipe.setIngredient(key.charAt(0), material);
            }
        }

        plugin.getServer().addRecipe(recipe);
    }
}
