package com.strengthsmp;

import com.strengthsmp.combat.AbilityManager;
import com.strengthsmp.commands.ReviveCommand;
import com.strengthsmp.commands.StrengthCommand;
import com.strengthsmp.commands.WithdrawCommand;
import com.strengthsmp.items.RerollToken;
import com.strengthsmp.items.StrengthToken;
import com.strengthsmp.listeners.JoinQuitListener;
import com.strengthsmp.listeners.PvPListener;
import com.strengthsmp.listeners.ShieldListener;
import com.strengthsmp.listeners.TokenListener;
import com.strengthsmp.listeners.TotemLimiterListener;
import com.strengthsmp.listeners.WeaponAbilityListener;
import com.strengthsmp.listeners.WitherDropListener;
import com.strengthsmp.managers.PlayerDataManager;
import org.bukkit.plugin.java.JavaPlugin;

public class StrengthSMPPlugin extends JavaPlugin {

    private PlayerDataManager dataManager;
    private StrengthToken strengthToken;
    private RerollToken rerollToken;
    private AbilityManager abilityManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.dataManager = new PlayerDataManager(this);
        this.strengthToken = new StrengthToken(this);
        this.rerollToken = new RerollToken(this);
        this.abilityManager = new AbilityManager();

        // Registra listeners
        getServer().getPluginManager().registerEvents(new PvPListener(this), this);
        getServer().getPluginManager().registerEvents(new JoinQuitListener(this), this);
        getServer().getPluginManager().registerEvents(new TokenListener(this), this);
        getServer().getPluginManager().registerEvents(new TotemLimiterListener(this), this);
        getServer().getPluginManager().registerEvents(new WeaponAbilityListener(this), this);
        getServer().getPluginManager().registerEvents(new ShieldListener(this), this);
        getServer().getPluginManager().registerEvents(new WitherDropListener(this), this);

        // Registra comandi
        getCommand("strength").setExecutor(new StrengthCommand(this));
        getCommand("revive").setExecutor(new ReviveCommand(this));
        getCommand("withdraw").setExecutor(new WithdrawCommand(this));

        // Registra ricette
        try {
            strengthToken.registerRecipe();
        } catch (Exception e) {
            getLogger().warning("Impossibile registrare la ricetta dello Strength Token: " + e.getMessage());
        }
        try {
            rerollToken.registerRecipe();
        } catch (Exception e) {
            getLogger().warning("Impossibile registrare la ricetta del Token del Destino: " + e.getMessage());
        }

        // Applica attributi a chi è già online (utile su /reload)
        for (var player : getServer().getOnlinePlayers()) {
            dataManager.getData(player);
            dataManager.applyStrengthAttribute(player);
        }

        getLogger().info("StrengthSMP abilitato! Che vinca il più forte.");
    }

    @Override
    public void onDisable() {
        if (dataManager != null) {
            dataManager.saveAll();
        }
        getLogger().info("StrengthSMP disabilitato, dati salvati.");
    }

    public PlayerDataManager getDataManager() {
        return dataManager;
    }

    public StrengthToken getStrengthToken() {
        return strengthToken;
    }

    public RerollToken getRerollToken() {
        return rerollToken;
    }

    public AbilityManager getAbilityManager() {
        return abilityManager;
    }
}
