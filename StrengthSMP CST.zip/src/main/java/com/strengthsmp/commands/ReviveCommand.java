package com.strengthsmp.commands;

import com.strengthsmp.StrengthSMPPlugin;
import com.strengthsmp.managers.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * /revive <player> - consuma uno Strength Token dalla mano del sender per
 * rianimare un giocatore che è stato eliminato per Strength negativa
 * (vedi elimination.* in config.yml).
 */
public class ReviveCommand implements CommandExecutor {

    private final StrengthSMPPlugin plugin;

    public ReviveCommand(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
    }

    private String prefix() {
        return ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", ""));
    }

    private String msg(String path) {
        return ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("elimination.messages." + path, ""));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player reviver)) {
            sender.sendMessage("Questo comando può essere usato solo in gioco.");
            return true;
        }

        if (!reviver.hasPermission("strengthsmp.revive")) {
            sender.sendMessage(prefix() + ChatColor.RED + "Non hai il permesso per usare questo comando.");
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage(prefix() + msg("revive-usage"));
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(prefix() + msg("revive-player-not-found"));
            return true;
        }

        PlayerData targetData = plugin.getDataManager().getData(target);
        if (!targetData.isEliminated()) {
            sender.sendMessage(prefix() + msg("revive-not-eliminated").replace("%player%", target.getName()));
            return true;
        }

        ItemStack handItem = reviver.getInventory().getItemInMainHand();
        if (!plugin.getStrengthToken().isToken(handItem) || handItem.getAmount() < 1) {
            sender.sendMessage(prefix() + msg("revive-need-item"));
            return true;
        }

        handItem.setAmount(handItem.getAmount() - 1);

        plugin.getDataManager().revive(target);

        int reviveStrength = plugin.getConfig().getInt("elimination.revive-strength", 0);

        reviver.sendMessage(prefix() + msg("revive-success")
                .replace("%player%", target.getName())
                .replace("%reviver%", reviver.getName()));

        target.sendMessage(prefix() + msg("revived-message")
                .replace("%reviver%", reviver.getName())
                .replace("%strength%", String.valueOf(reviveStrength)));

        return true;
    }
}
