package com.strengthsmp.commands;

import com.strengthsmp.StrengthSMPPlugin;
import com.strengthsmp.managers.PlayerData;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * /withdraw <amount> - converte N punti Strength del giocatore in N
 * Strength Token fisici, consegnati in mano (o nell'inventario se la mano
 * è occupata). Es: hai 4 Strength, "/withdraw 1" -> resti con 3 Strength e
 * ricevi 1 Strength Token.
 */
public class WithdrawCommand implements CommandExecutor {

    private final StrengthSMPPlugin plugin;

    public WithdrawCommand(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
    }

    private String prefix() {
        return ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", ""));
    }

    private String msg(String path) {
        return ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("withdraw.messages." + path, ""));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Questo comando può essere usato solo in gioco.");
            return true;
        }

        if (!player.hasPermission("strengthsmp.use")) {
            sender.sendMessage(prefix() + ChatColor.RED + "Non hai il permesso per usare questo comando.");
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage(prefix() + msg("usage"));
            return true;
        }

        int amount;
        try {
            amount = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            sender.sendMessage(prefix() + msg("usage"));
            return true;
        }

        if (amount <= 0) {
            sender.sendMessage(prefix() + msg("invalid-amount"));
            return true;
        }

        PlayerData data = plugin.getDataManager().getData(player);
        int minStrength = plugin.getDataManager().getMinStrength();

        if (data.getStrength() - amount < minStrength) {
            sender.sendMessage(prefix() + msg("not-enough")
                    .replace("%strength%", String.valueOf(data.getStrength())));
            return true;
        }

        plugin.getDataManager().addStrength(player, -amount);

        ItemStack tokens = plugin.getStrengthToken().createToken();
        tokens.setAmount(amount);

        var leftover = player.getInventory().addItem(tokens);
        for (ItemStack extra : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), extra);
        }

        int newStrength = plugin.getDataManager().getData(player).getStrength();
        sender.sendMessage(prefix() + msg("success")
                .replace("%amount%", String.valueOf(amount))
                .replace("%strength%", String.valueOf(newStrength)));
        player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1f, 1.2f);

        return true;
    }
}
