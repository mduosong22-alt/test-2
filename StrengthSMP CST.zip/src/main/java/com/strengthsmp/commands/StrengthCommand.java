package com.strengthsmp.commands;

import com.strengthsmp.StrengthSMPPlugin;
import com.strengthsmp.managers.PlayerData;
import org.bukkit.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class StrengthCommand implements CommandExecutor {

    private final StrengthSMPPlugin plugin;

    public StrengthCommand(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
    }

    private String prefix() {
        return ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", ""));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "get" -> handleGet(sender, args);
            case "set" -> handleSet(sender, args);
            case "top" -> handleTop(sender);
            case "reset" -> handleReset(sender, args);
            case "class" -> handleClass(sender);
            case "help" -> sendHelp(sender);
            default -> sendHelp(sender);
        }
        return true;
    }

    private void handleClass(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(prefix() + ChatColor.RED + "Questo comando può essere usato solo in gioco.");
            return;
        }
        var playerClass = plugin.getDataManager().getPlayerClass(player);
        if (playerClass == null) {
            sender.sendMessage(prefix() + ChatColor.RED + "Non hai ancora una classe assegnata.");
            return;
        }
        sender.sendMessage(prefix() + ChatColor.GRAY + "La tua classe è: "
                + playerClass.getColor() + playerClass.getDisplayName()
                + ChatColor.GRAY + " — puoi usare solo le sue abilità speciali.");
    }

    private void handleGet(CommandSender sender, String[] args) {
        Player target;
        if (args.length >= 2) {
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(prefix() + ChatColor.RED + "Giocatore non trovato o offline.");
                return;
            }
        } else if (sender instanceof Player p) {
            target = p;
        } else {
            sender.sendMessage(prefix() + ChatColor.RED + "Specifica un giocatore.");
            return;
        }

        PlayerData data = plugin.getDataManager().getData(target);
        var playerClass = data.getWeaponClass();
        String classText = playerClass != null
                ? playerClass.getColor() + playerClass.getDisplayName()
                : ChatColor.GRAY + "nessuna";
        double multiplier = plugin.getDataManager().getDamageMultiplier(target);
        sender.sendMessage(prefix() + ChatColor.AQUA + target.getName() + ChatColor.GRAY + " ha "
                + ChatColor.WHITE + data.getStrength() + ChatColor.GRAY + " Strength "
                + ChatColor.DARK_GRAY + "(x" + String.format("%.1f", multiplier) + " danno)" + ChatColor.GRAY
                + " — " + data.getKills() + " kills, " + data.getDeaths() + " morti — classe: " + classText);
    }

    private void handleSet(CommandSender sender, String[] args) {
        if (!sender.hasPermission("strengthsmp.admin")) {
            sender.sendMessage(prefix() + ChatColor.RED + "Non hai il permesso per usare questo comando.");
            return;
        }
        if (args.length < 3) {
            sender.sendMessage(prefix() + ChatColor.RED + "Uso: /strength set <player> <value>");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(prefix() + ChatColor.RED + "Giocatore non trovato o offline.");
            return;
        }

        int value;
        try {
            value = Integer.parseInt(args[2]);
        } catch (NumberFormatException e) {
            sender.sendMessage(prefix() + ChatColor.RED + "Il valore deve essere un numero.");
            return;
        }

        plugin.getDataManager().setStrength(target, value);
        sender.sendMessage(prefix() + ChatColor.GREEN + "Strength di " + target.getName() + " impostata a " + value + ".");
        target.sendMessage(prefix() + ChatColor.YELLOW + "La tua Strength è stata impostata a " + value + " da un admin.");
    }

    private void handleReset(CommandSender sender, String[] args) {
        if (!sender.hasPermission("strengthsmp.admin")) {
            sender.sendMessage(prefix() + ChatColor.RED + "Non hai il permesso per usare questo comando.");
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(prefix() + ChatColor.RED + "Uso: /strength reset <player>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(prefix() + ChatColor.RED + "Giocatore non trovato o offline.");
            return;
        }
        plugin.getDataManager().setStrength(target, plugin.getConfig().getInt("strength.starting-strength", 0));
        sender.sendMessage(prefix() + ChatColor.GREEN + "Strength di " + target.getName() + " resettata.");
    }

    private void handleTop(CommandSender sender) {
        Map<UUID, PlayerData> all = plugin.getDataManager().getAllCachedData();
        List<PlayerData> sorted = all.values().stream()
                .sorted(Comparator.comparingInt(PlayerData::getStrength).reversed())
                .limit(10)
                .collect(Collectors.toList());

        sender.sendMessage(prefix() + ChatColor.GOLD + "=== Top 10 Strength ===");
        int rank = 1;
        for (PlayerData data : sorted) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(data.getUuid());
            String name = op.getName() != null ? op.getName() : data.getUuid().toString();
            sender.sendMessage(ChatColor.YELLOW + "#" + rank + " " + ChatColor.WHITE + name
                    + ChatColor.GRAY + " - " + ChatColor.AQUA + data.getStrength() + " Strength");
            rank++;
        }
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(prefix() + ChatColor.GOLD + "=== Comandi StrengthSMP ===");
        sender.sendMessage(ChatColor.AQUA + "/strength get [player]" + ChatColor.GRAY + " - Mostra la Strength");
        sender.sendMessage(ChatColor.AQUA + "/strength class" + ChatColor.GRAY + " - Mostra la tua classe arma");
        sender.sendMessage(ChatColor.AQUA + "/strength top" + ChatColor.GRAY + " - Classifica dei più forti");
        if (sender.hasPermission("strengthsmp.admin")) {
            sender.sendMessage(ChatColor.AQUA + "/strength set <player> <value>" + ChatColor.GRAY + " - Imposta la Strength (admin)");
            sender.sendMessage(ChatColor.AQUA + "/strength reset <player>" + ChatColor.GRAY + " - Resetta la Strength (admin)");
        }
    }
}
