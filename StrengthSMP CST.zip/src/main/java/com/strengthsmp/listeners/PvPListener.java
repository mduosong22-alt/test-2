package com.strengthsmp.listeners;

import com.strengthsmp.StrengthSMPPlugin;
import com.strengthsmp.managers.PlayerData;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.potion.PotionEffectType;

public class PvPListener implements Listener {

    private final StrengthSMPPlugin plugin;

    public PvPListener(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        boolean onlyPvp = plugin.getConfig().getBoolean("strength.only-pvp-affects-strength", true);
        String msgPrefix = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", ""));

        // Se non c'è un killer giocatore e la config richiede solo PvP, non tocchiamo la strength
        if (killer == null) {
            if (!onlyPvp) {
                // morte per mob/ambiente conta comunque come perdita
                applyDeathPenalty(victim, null, msgPrefix);
            }
            return;
        }

        if (killer.equals(victim)) return; // suicidio non conta

        int gain = plugin.getConfig().getInt("strength.strength-per-kill", 1);

        // Killer guadagna Strength
        plugin.getDataManager().addStrength(killer, gain);
        PlayerData killerData = plugin.getDataManager().getData(killer);
        killerData.incrementKills();

        String killMsg = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.kill-gain", ""))
                .replace("%amount%", String.valueOf(gain))
                .replace("%total%", String.valueOf(killerData.getStrength()))
                .replace("%victim%", victim.getName());
        killer.sendMessage(msgPrefix + killMsg);

        // Victim perde Strength
        applyDeathPenalty(victim, killer, msgPrefix);

        // Se il killer è invisibile al momento della kill, il suo nome non compare
        // né nel broadcast né nel messaggio di morte vanilla
        boolean hideName = plugin.getConfig().getBoolean("invisible-kill.hide-name", true)
                && killer.hasPotionEffect(PotionEffectType.INVISIBILITY);
        String displayKillerName = hideName
                ? ChatColor.translateAlternateColorCodes('&',
                        plugin.getConfig().getString("invisible-kill.hidden-name", "&8Qualcuno nell'ombra"))
                : killer.getName();

        // Broadcast pubblico
        String broadcast = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.broadcast-kill", ""))
                .replace("%killer%", displayKillerName)
                .replace("%victim%", victim.getName())
                .replace("%strength%", String.valueOf(killerData.getStrength()));
        plugin.getServer().broadcastMessage(msgPrefix + broadcast);

        if (hideName) {
            String hiddenDeathMsg = ChatColor.translateAlternateColorCodes('&',
                    plugin.getConfig().getString("invisible-kill.hidden-death-message",
                            "&7%victim% &7è stato ucciso da qualcuno nell'ombra..."))
                    .replace("%victim%", victim.getName());
            event.setDeathMessage(hiddenDeathMsg);
        }
    }

    private void applyDeathPenalty(Player victim, Player killer, String msgPrefix) {
        int loss = plugin.getConfig().getInt("strength.strength-loss-per-death", 1);
        plugin.getDataManager().addStrength(victim, -loss);
        PlayerData victimData = plugin.getDataManager().getData(victim);
        victimData.incrementDeaths();

        if (killer != null) {
            String deathMsg = ChatColor.translateAlternateColorCodes('&',
                    plugin.getConfig().getString("messages.death-loss", ""))
                    .replace("%amount%", String.valueOf(loss))
                    .replace("%total%", String.valueOf(victimData.getStrength()))
                    .replace("%killer%", killer.getName());
            victim.sendMessage(msgPrefix + deathMsg);
        }

        // Nessun sistema di vite: la morte costa solo Strength.
        // Se la Strength scende sotto la soglia di eliminazione, PlayerDataManager
        // mette il giocatore in spettatore; può essere rianimato un numero
        // illimitato di volte con "/revive <player>" (vedi ReviveCommand).
    }
}
