package com.strengthsmp.listeners;

import com.strengthsmp.StrengthSMPPlugin;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerAttemptPickupItemEvent;
import org.bukkit.inventory.ItemStack;

public class TotemLimiterListener implements Listener {

    private final StrengthSMPPlugin plugin;

    public TotemLimiterListener(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean isEnabled() {
        return plugin.getConfig().getBoolean("totem-limiter.enabled", true);
    }

    private int getMaxTotems() {
        return plugin.getConfig().getInt("totem-limiter.max-totems", 1);
    }

    private int countTotems(Player player) {
        int count = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == Material.TOTEM_OF_UNDYING) {
                count += item.getAmount();
            }
        }
        return count;
    }

    private void warn(Player player) {
        String msg = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("totem-limiter.warning-message", ""))
                .replace("%max%", String.valueOf(getMaxTotems()));
        player.sendMessage(msg);
    }

    @EventHandler
    public void onPickup(PlayerAttemptPickupItemEvent event) {
        if (!isEnabled()) return;
        if (event.getItem().getItemStack().getType() != Material.TOTEM_OF_UNDYING) return;

        Player player = event.getPlayer();
        int current = countTotems(player);
        int incoming = event.getItem().getItemStack().getAmount();

        if (current + incoming > getMaxTotems()) {
            event.setCancelled(true);
            warn(player);
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!isEnabled()) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;

        ItemStack cursor = event.getCursor();
        if (cursor != null && cursor.getType() == Material.TOTEM_OF_UNDYING) {
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (countTotems(player) > getMaxTotems()) {
                    sanitize(player);
                }
            });
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!isEnabled()) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getOldCursor().getType() != Material.TOTEM_OF_UNDYING) return;

        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (countTotems(player) > getMaxTotems()) {
                sanitize(player);
            }
        });
    }

    /** Rimuove i totem in eccesso e li fa cadere a terra ai piedi del giocatore */
    private void sanitize(Player player) {
        int excess = countTotems(player) - getMaxTotems();
        if (excess <= 0) return;

        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length && excess > 0; i++) {
            ItemStack item = contents[i];
            if (item != null && item.getType() == Material.TOTEM_OF_UNDYING) {
                int remove = Math.min(excess, item.getAmount());
                item.setAmount(item.getAmount() - remove);
                excess -= remove;
                if (item.getAmount() <= 0) {
                    player.getInventory().setItem(i, null);
                }
                player.getWorld().dropItem(player.getLocation(), new ItemStack(Material.TOTEM_OF_UNDYING, remove));
            }
        }
        warn(player);
    }
}
