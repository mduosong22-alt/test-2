package com.strengthsmp.listeners;

import com.strengthsmp.StrengthSMPPlugin;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Sostituisce il drop di default del Wither (1 Nether Star) con:
 * 1 Nether Star normale + N Strength Token (configurabili in config.yml,
 * sezione "wither-drop").
 */
public class WitherDropListener implements Listener {

    private final StrengthSMPPlugin plugin;

    public WitherDropListener(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onWitherDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.getType() != EntityType.WITHER) return;
        if (!plugin.getConfig().getBoolean("wither-drop.enabled", true)) return;

        // Rimuove la/le Nether Star vanilla generate di default dal drop
        event.getDrops().removeIf(item -> item.getType() == Material.NETHER_STAR);

        int normalStars = plugin.getConfig().getInt("wither-drop.normal-nether-stars", 1);
        int tokens = plugin.getConfig().getInt("wither-drop.strength-tokens", 3);

        if (normalStars > 0) {
            event.getDrops().add(new ItemStack(Material.NETHER_STAR, normalStars));
        }
        if (tokens > 0) {
            ItemStack token = plugin.getStrengthToken().createToken();
            token.setAmount(tokens);
            event.getDrops().add(token);
        }
    }
}
