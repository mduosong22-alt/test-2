package com.strengthsmp.listeners;

import com.strengthsmp.StrengthSMPPlugin;
import com.strengthsmp.combat.AbilityManager;
import com.strengthsmp.managers.PlayerClass;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * Gestisce le abilità speciali delle 5 classi arma (Spada, Ascia, Scudo,
 * Tridente, Arco) più la Mazza. Ogni giocatore può usare SOLO le abilità
 * dell'arma corrispondente alla propria classe (vedi PlayerDataManager /
 * PlayerClass). Tutte le abilità "attivabili" (Shift + click destro) hanno
 * una ricarica uniforme configurabile in abilities.cooldown-seconds
 * (default 45s).
 */
public class WeaponAbilityListener implements Listener {

    private final StrengthSMPPlugin plugin;
    private final AbilityManager abilityManager;

    public WeaponAbilityListener(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
        this.abilityManager = plugin.getAbilityManager();
    }

    private String prefix() {
        return ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", ""));
    }

    private long abilityCooldownSeconds() {
        return plugin.getConfig().getLong("abilities.cooldown-seconds", 45);
    }

    private boolean isClass(Player player, PlayerClass required) {
        return plugin.getDataManager().isClass(player, required);
    }

    // ================== ATTIVAZIONE ABILITÀ (click destro) ==================

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (!event.getAction().isRightClick()) return;

        Player player = event.getPlayer();

        // TRIDENTE: gestito sia per mano principale che secondaria, perché il
        // lancio vanilla va intercettato prima che parta la "carica".
        ItemStack item = event.getItem();

        if (item != null && item.getType() == Material.TRIDENT && isClass(player, PlayerClass.TRIDENT)) {
            if (player.isSneaking()) {
                event.setCancelled(true);
                activateTridentAbility(player);
            }
            return; // non sneaking: lascia partire il lancio vanilla normale
        }

        if (event.getHand() != EquipmentSlot.HAND) return;
        if (item == null) return;
        if (!player.isSneaking()) return;

        Material type = item.getType();
        if (type.name().endsWith("_SWORD") && isClass(player, PlayerClass.SWORD)) {
            event.setCancelled(true);
            activateSwordAbility(player);
        } else if (type.name().endsWith("_AXE") && isClass(player, PlayerClass.AXE)) {
            event.setCancelled(true);
            activateAxeAbility(player);
        } else if (type == Material.SHIELD && isClass(player, PlayerClass.SHIELD)) {
            event.setCancelled(true);
            activateShieldAbility(player);
        }
    }

    // ---------- SPADA ----------

    private void activateSwordAbility(Player player) {
        UUID id = player.getUniqueId();
        if (!abilityManager.isSwordComboReady(id)) return;

        if (abilityManager.isOnCooldown("sword_ability", id)) {
            sendCooldownMessage(player, "weapons.sword.messages.on-cooldown",
                    abilityManager.getRemainingSeconds("sword_ability", id));
            return;
        }

        abilityManager.setSwordComboReady(id, false);
        abilityManager.setCooldown("sword_ability", id, abilityCooldownSeconds());

        long durationSeconds = plugin.getConfig().getLong("weapons.sword.ability-duration-seconds", 15);
        abilityManager.setSwordCritActiveUntil(id, System.currentTimeMillis() + durationSeconds * 1000L);

        ItemStack currentOffhand = player.getInventory().getItemInOffHand();
        abilityManager.saveOffhand(id, currentOffhand.getType() == Material.AIR ? null : currentOffhand.clone());

        ItemStack phantomSword = player.getInventory().getItemInMainHand().clone();
        ItemMeta meta = phantomSword.getItemMeta();
        if (meta != null) {
            meta.addEnchant(Enchantment.LOYALTY, 1, true); // solo effetto glint estetico
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            phantomSword.setItemMeta(meta);
        }
        player.getInventory().setItemInOffHand(phantomSword);

        player.sendMessage(prefix() + ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("weapons.sword.messages.activated", ""))
                .replace("%seconds%", String.valueOf(durationSeconds)));
        player.sendTitle(ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "FURIA DELLA LAMA", "", 0, 30, 10);
        player.getWorld().spawnParticle(Particle.END_ROD, player.getLocation().add(0, 1, 0), 40, 0.5, 0.8, 0.5, 0.05);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 2f);

        Bukkit.getScheduler().runTaskLater(plugin, () -> restoreOffhand(player, id), durationSeconds * 20L);
    }

    private void restoreOffhand(Player player, UUID id) {
        abilityManager.clearSwordCritActive(id);
        if (!abilityManager.hasSavedOffhand(id)) return;

        ItemStack saved = abilityManager.takeSavedOffhand(id);
        if (player.isOnline()) {
            player.getInventory().setItemInOffHand(saved);
            player.sendMessage(prefix() + ChatColor.GRAY + "L'effetto della Furia della Lama è terminato.");
        }
    }

    // ---------- ASCIA ----------

    private void activateAxeAbility(Player player) {
        UUID id = player.getUniqueId();

        if (abilityManager.isOnCooldown("axe_ability", id)) {
            sendCooldownMessage(player, "weapons.axe.messages.on-cooldown",
                    abilityManager.getRemainingSeconds("axe_ability", id));
            return;
        }

        abilityManager.setCooldown("axe_ability", id, abilityCooldownSeconds());
        long durationSeconds = plugin.getConfig().getLong("weapons.axe.special-duration-seconds", 10);
        abilityManager.setAxeDoubleCritUntil(id, System.currentTimeMillis() + durationSeconds * 1000L);

        player.sendMessage(prefix() + ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("weapons.axe.messages.activated", ""))
                .replace("%seconds%", String.valueOf(durationSeconds)));
        player.sendTitle(ChatColor.GOLD + "" + ChatColor.BOLD + "FURIA DEL BOSCAIOLO", "", 0, 30, 10);
        player.getWorld().spawnParticle(Particle.FLAME, player.getLocation().add(0, 1, 0), 30, 0.4, 0.8, 0.4, 0.03);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1f, 0.6f);
    }

    // ---------- SCUDO ----------

    private void activateShieldAbility(Player player) {
        UUID id = player.getUniqueId();

        if (abilityManager.isOnCooldown("shield_ability", id)) {
            sendCooldownMessage(player, "weapons.shield.messages.on-cooldown",
                    abilityManager.getRemainingSeconds("shield_ability", id));
            return;
        }

        abilityManager.setCooldown("shield_ability", id, abilityCooldownSeconds());

        int durationSeconds = plugin.getConfig().getInt("weapons.shield.ability-immortal-seconds", 10);
        int slowAmplifier = plugin.getConfig().getInt("weapons.shield.ability-slowness-amplifier", 1);

        abilityManager.setShieldImmortalUntil(id, System.currentTimeMillis() + durationSeconds * 1000L);
        player.setInvulnerable(true);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, durationSeconds * 20, slowAmplifier, false, true, true));

        player.sendMessage(prefix() + ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("weapons.shield.messages.ability-activated", ""))
                .replace("%seconds%", String.valueOf(durationSeconds)));
        player.sendTitle(ChatColor.AQUA + "" + ChatColor.BOLD + "AEGIS INFRANGIBILE", "", 0, 30, 10);
        player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation().add(0, 1, 0), 40, 0.5, 1, 0.5, 0.1);
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 1f, 1.3f);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                player.setInvulnerable(false);
            }
        }, durationSeconds * 20L);
    }

    // ---------- TRIDENTE ----------

    /**
     * Lo "Scatto" del Tridente si attiva con Shift + tasto di scambio mano
     * (F di default), per non entrare in conflitto con Shift + click destro
     * (usato per "Ira di Nettuno"). Ha una ricarica FISSA di 20 secondi,
     * indipendente e più breve rispetto alla ricarica generale delle abilità.
     */
    @EventHandler
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (!player.isSneaking()) return;
        if (!isClass(player, PlayerClass.TRIDENT)) return;

        ItemStack main = event.getMainHandItem();
        ItemStack off = event.getOffHandItem();
        boolean holdingTrident = (main != null && main.getType() == Material.TRIDENT)
                || (off != null && off.getType() == Material.TRIDENT);
        if (!holdingTrident) return;

        event.setCancelled(true);
        activateTridentDash(player);
    }

    private void activateTridentDash(Player player) {
        UUID id = player.getUniqueId();
        long cooldownSeconds = plugin.getConfig().getLong("weapons.trident.dash-cooldown-seconds", 20);

        if (abilityManager.isOnCooldown("trident_dash", id)) {
            sendCooldownMessage(player, "weapons.trident.messages.dash-on-cooldown",
                    abilityManager.getRemainingSeconds("trident_dash", id));
            return;
        }

        abilityManager.setCooldown("trident_dash", id, cooldownSeconds);

        double power = plugin.getConfig().getDouble("weapons.trident.dash-power", 1.7);
        double vertical = plugin.getConfig().getDouble("weapons.trident.dash-vertical-boost", 0.35);
        Vector direction = player.getLocation().getDirection().normalize();
        Vector velocity = direction.multiply(power).setY(vertical);
        player.setVelocity(velocity);

        player.sendMessage(prefix() + ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("weapons.trident.messages.dash-activated", "")));
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 25, 0.3, 0.2, 0.3, 0.05);
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_TRIDENT_RIPTIDE_1, 1f, 1.2f);
    }

    private void activateTridentAbility(Player player) {
        UUID id = player.getUniqueId();

        if (abilityManager.isOnCooldown("trident_ability", id)) {
            sendCooldownMessage(player, "weapons.trident.messages.on-cooldown",
                    abilityManager.getRemainingSeconds("trident_ability", id));
            return;
        }

        abilityManager.setCooldown("trident_ability", id, abilityCooldownSeconds());

        double radius = plugin.getConfig().getDouble("weapons.trident.ability-radius", 6.0);
        int boltCount = plugin.getConfig().getInt("weapons.trident.ability-bolt-count", 5);
        double damage = plugin.getConfig().getDouble("weapons.trident.ability-damage", 4.0);
        long slowSeconds = plugin.getConfig().getLong("weapons.trident.ability-slow-seconds", 5);
        int slowAmplifier = plugin.getConfig().getInt("weapons.trident.ability-slow-amplifier", 0);

        List<Entity> nearby = player.getNearbyEntities(radius, radius, radius);
        int bolts = 0;
        for (Entity entity : nearby) {
            if (bolts >= boltCount) break;
            if (!(entity instanceof LivingEntity target)) continue;
            if (target.equals(player)) continue;

            Location strikeLoc = target.getLocation();
            player.getWorld().strikeLightningEffect(strikeLoc);
            target.damage(damage, player);
            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) (slowSeconds * 20), slowAmplifier, false, true, true));
            bolts++;
        }

        if (bolts == 0) {
            // Nessun nemico vicino: colpo puramente scenico ai piedi del giocatore
            player.getWorld().strikeLightningEffect(player.getLocation());
        }

        player.sendMessage(prefix() + ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("weapons.trident.messages.ability-activated", "")));
        player.sendTitle(ChatColor.DARK_AQUA + "" + ChatColor.BOLD + "IRA DI NETTUNO", "", 0, 30, 10);
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_TRIDENT_THUNDER, 1f, 1f);
    }

    private void sendCooldownMessage(Player player, String path, long remainingSeconds) {
        String msg = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString(path, ""))
                .replace("%seconds%", String.valueOf(remainingSeconds));
        player.sendMessage(prefix() + msg);
        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
    }

    // ================== COMBATTIMENTO (colpi a segno) ==================

    @EventHandler(priority = EventPriority.HIGH)
    public void onCombatDamage(EntityDamageByEntityEvent event) {
        if (event.isCancelled()) return;

        // Colpo con Tridente lanciato (proiettile)
        if (event.getDamager() instanceof Trident trident) {
            ProjectileSource shooter = trident.getShooter();
            if (shooter instanceof Player attacker && event.getEntity() instanceof LivingEntity victim
                    && !victim.equals(attacker) && isClass(attacker, PlayerClass.TRIDENT)) {
                handleTridentHit(attacker, victim);
            }
            return;
        }

        // Colpo con Freccia
        if (event.getDamager() instanceof Arrow arrow) {
            ProjectileSource shooter = arrow.getShooter();
            if (shooter instanceof Player attacker && event.getEntity() instanceof LivingEntity victim
                    && !victim.equals(attacker) && isClass(attacker, PlayerClass.BOW)) {
                handleBowHit(event, attacker, victim);
            }
            return;
        }

        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof LivingEntity victim)) return;

        ItemStack weapon = attacker.getInventory().getItemInMainHand();
        Material type = weapon.getType();

        if (type == Material.MACE) {
            handleMaceHit(event, attacker);
            if (event.isCancelled()) return;
        }

        if (type.name().endsWith("_SWORD") && isClass(attacker, PlayerClass.SWORD)) {
            handleSwordHit(event, attacker, victim);
        } else if (type.name().endsWith("_AXE") && isClass(attacker, PlayerClass.AXE)) {
            handleAxeHit(event, attacker, victim);
        } else if (type == Material.TRIDENT && isClass(attacker, PlayerClass.TRIDENT)) {
            handleTridentHit(attacker, victim);
        }

        // Danno dimezzato se lo scudo del difensore è stato appena disattivato
        if (event.getEntity() instanceof Player defender
                && isClass(defender, PlayerClass.SHIELD)
                && abilityManager.isShieldHalfDamageActive(defender.getUniqueId())) {
            event.setDamage(event.getDamage() * 0.5);
        }
    }

    private void handleMaceHit(EntityDamageByEntityEvent event, Player attacker) {
        UUID id = attacker.getUniqueId();
        int cooldownSeconds = plugin.getConfig().getInt("weapons.mace.cooldown-seconds", 60);

        if (abilityManager.isOnCooldown("mace", id)) {
            event.setCancelled(true);
            sendCooldownMessage(attacker, "weapons.mace.messages.on-cooldown",
                    abilityManager.getRemainingSeconds("mace", id));
            return;
        }

        abilityManager.setCooldown("mace", id, cooldownSeconds);
        attacker.setCooldown(Material.MACE, cooldownSeconds * 20);
        attacker.getWorld().spawnParticle(Particle.EXPLOSION, event.getEntity().getLocation().add(0, 1, 0), 1);
        attacker.getWorld().playSound(attacker.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 1.4f);
    }

    private void handleSwordHit(EntityDamageByEntityEvent event, Player attacker, LivingEntity victim) {
        UUID id = attacker.getUniqueId();

        if (abilityManager.isSwordCritActive(id)) {
            event.setDamage(event.getDamage() * 1.5);
            victim.getWorld().spawnParticle(Particle.CRIT, victim.getLocation().add(0, 1, 0), 12, 0.3, 0.3, 0.3, 0.05);
            victim.getWorld().playSound(victim.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 1f);
            return; // durante l'abilità attiva non si riaccumula la combo
        }

        long timeoutSeconds = plugin.getConfig().getLong("weapons.sword.combo-timeout-seconds", 3);
        abilityManager.registerSwordHit(id, timeoutSeconds);

        int required = plugin.getConfig().getInt("weapons.sword.combo-required", 5);
        int combo = abilityManager.getSwordCombo(id);

        if (combo >= required && !abilityManager.isSwordComboReady(id)) {
            abilityManager.setSwordComboReady(id, true);
            abilityManager.resetSwordCombo(id);

            attacker.sendMessage(prefix() + ChatColor.translateAlternateColorCodes('&',
                    plugin.getConfig().getString("weapons.sword.messages.combo-ready", "")));
            attacker.sendTitle(ChatColor.LIGHT_PURPLE + "COMBO!", ChatColor.GRAY + "Abilità pronta", 5, 40, 10);
            attacker.getWorld().spawnParticle(Particle.CRIT, attacker.getLocation().add(0, 1, 0), 20, 0.3, 0.5, 0.3, 0.05);
            attacker.playSound(attacker.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
        }
    }

    private void handleAxeHit(EntityDamageByEntityEvent event, Player attacker, LivingEntity victim) {
        UUID id = attacker.getUniqueId();

        if (abilityManager.isAxeDoubleCritActive(id) && isCriticalHit(attacker)) {
            event.setDamage(event.getDamage() * 2.0);
            victim.getWorld().spawnParticle(Particle.CRIT, victim.getLocation().add(0, 1, 0), 20, 0.3, 0.3, 0.3, 0.08);
            victim.getWorld().playSound(victim.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.2f, 0.7f);
        }

        int every = plugin.getConfig().getInt("weapons.axe.stun-every-hits", 3);
        int count = abilityManager.incrementAndGetAxeHits(id);

        if (count >= every) {
            abilityManager.resetAxeHits(id);
            if (victim instanceof Player victimPlayer) {
                long duration = plugin.getConfig().getLong("weapons.axe.stun-duration-seconds", 1);
                abilityManager.freeze(victimPlayer.getUniqueId(), duration);

                victimPlayer.sendMessage(prefix() + ChatColor.translateAlternateColorCodes('&',
                        plugin.getConfig().getString("weapons.axe.messages.stunned", "")));
                victimPlayer.sendTitle(ChatColor.GOLD + "" + ChatColor.BOLD + "STORDITO!", "", 0, 20, 5);
                victimPlayer.getWorld().spawnParticle(Particle.FLAME, victimPlayer.getLocation().add(0, 1, 0), 25, 0.4, 0.6, 0.4, 0.02);
                victimPlayer.getWorld().playSound(victimPlayer.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.7f, 1.8f);
            }
        }
    }

    /** Ogni 2 colpi (mischia con Tridente equipaggiato o Tridente lanciato) scaglia un fulmine sul bersaglio. */
    private void handleTridentHit(Player attacker, LivingEntity victim) {
        UUID id = attacker.getUniqueId();
        int every = 2;
        int count = abilityManager.incrementAndGetTridentHits(id);

        if (count >= every) {
            abilityManager.resetTridentHits(id);

            double damage = plugin.getConfig().getDouble("weapons.trident.lightning-damage", 3.0);
            victim.getWorld().strikeLightningEffect(victim.getLocation());
            victim.damage(damage, attacker);
            victim.getWorld().playSound(victim.getLocation(), Sound.ITEM_TRIDENT_THUNDER, 0.8f, 1.2f);
        }
    }

    /** Dopo 3 colpi di fila con l'arco, la freccia successiva esplode (senza danneggiare i blocchi). */
    private void handleBowHit(EntityDamageByEntityEvent event, Player attacker, LivingEntity victim) {
        UUID id = attacker.getUniqueId();

        if (abilityManager.isBowExplosiveReady(id)) {
            abilityManager.setBowExplosiveReady(id, false);
            abilityManager.setCooldown("bow_ability", id, abilityCooldownSeconds());

            double radius = plugin.getConfig().getDouble("weapons.bow.explosion-radius", 3.0);
            double damage = plugin.getConfig().getDouble("weapons.bow.explosion-damage", 4.0);
            Location center = victim.getLocation();

            center.getWorld().spawnParticle(Particle.EXPLOSION, center.add(0, 1, 0), 1);
            center.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1.2f);

            for (Entity entity : victim.getNearbyEntities(radius, radius, radius)) {
                if (entity.equals(attacker)) continue;
                if (entity instanceof LivingEntity nearby) {
                    nearby.damage(damage, attacker);
                }
            }

            attacker.sendMessage(prefix() + ChatColor.translateAlternateColorCodes('&',
                    plugin.getConfig().getString("weapons.bow.messages.exploded", "")));

            handleBowRainStreak(attacker, victim);
            return;
        }

        if (!abilityManager.isOnCooldown("bow_ability", id)) {
            int required = plugin.getConfig().getInt("weapons.bow.streak-required", 3);
            int streak = abilityManager.incrementAndGetBowStreak(id);

            if (streak >= required) {
                abilityManager.resetBowStreak(id);
                abilityManager.setBowExplosiveReady(id, true);

                attacker.sendMessage(prefix() + ChatColor.translateAlternateColorCodes('&',
                        plugin.getConfig().getString("weapons.bow.messages.armed", "")));
                attacker.sendTitle(ChatColor.GREEN + "" + ChatColor.BOLD + "FRECCIA ESPLOSIVA PRONTA!", "", 0, 30, 10);
                attacker.playSound(attacker.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
            }
        }

        handleBowRainStreak(attacker, victim);
    }

    /**
     * Traccia la serie di colpi consecutivi "puliti" (senza mancare né essere colpiti)
     * per l'abilità speciale "Pioggia di Frecce": 5 colpi di fila fanno cadere
     * 20 frecce sparse a cerchio sul nemico.
     */
    private void handleBowRainStreak(Player attacker, LivingEntity victim) {
        UUID id = attacker.getUniqueId();

        if (abilityManager.isOnCooldown("bow_rain_ability", id)) {
            return; // in ricarica: non si riarma finché non passano i 45s
        }

        int required = plugin.getConfig().getInt("weapons.bow.rain-streak-required", 5);
        int streak = abilityManager.incrementAndGetBowRainStreak(id);

        if (streak >= required) {
            abilityManager.resetBowRainStreak(id);
            abilityManager.setCooldown("bow_rain_ability", id, abilityCooldownSeconds());
            activateArrowRain(attacker, victim);
        }
    }

    /** Fa cadere 20 frecce sparse a cerchio (non tutte precise) sul nemico bersaglio. */
    private void activateArrowRain(Player attacker, LivingEntity victim) {
        double radius = plugin.getConfig().getDouble("weapons.bow.rain-radius", 3.0);
        int arrowCount = plugin.getConfig().getInt("weapons.bow.rain-arrow-count", 20);
        double damage = plugin.getConfig().getDouble("weapons.bow.rain-damage", 6.0);
        double height = plugin.getConfig().getDouble("weapons.bow.rain-height", 6.0);

        Location base = victim.getLocation();
        Random random = new Random();

        for (int i = 0; i < arrowCount; i++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double r = random.nextDouble() * radius;
            double x = base.getX() + Math.cos(angle) * r;
            double z = base.getZ() + Math.sin(angle) * r;
            Location spawnLoc = new Location(base.getWorld(), x, base.getY() + height + random.nextDouble() * 2, z);

            base.getWorld().spawn(spawnLoc, Arrow.class, a -> {
                a.setShooter(attacker);
                a.setVelocity(new Vector((random.nextDouble() - 0.5) * 0.15, -1.1, (random.nextDouble() - 0.5) * 0.15));
                a.setDamage(0.0); // puramente scenico: il danno vero è applicato a parte
                a.setCritical(false);
            });
        }

        // Colpo garantito sul bersaglio principale, a rappresentare le frecce
        // che effettivamente lo colpiscono in mezzo alla pioggia scagliata a cerchio
        victim.damage(damage, attacker);

        base.getWorld().spawnParticle(Particle.CRIT, base.clone().add(0, 1, 0), 40, radius * 0.5, 1, radius * 0.5, 0.1);
        base.getWorld().playSound(base, Sound.ENTITY_ARROW_SHOOT, 1.5f, 0.6f);

        attacker.sendMessage(prefix() + ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("weapons.bow.messages.rain-activated", "")));
        attacker.sendTitle(ChatColor.GREEN + "" + ChatColor.BOLD + "PIOGGIA DI FRECCE!", "", 0, 30, 10);
        attacker.playSound(attacker.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 0.8f);
    }

    /** Approssimazione standard del colpo critico vanilla: caduta, non a terra, non in sprint. */
    private boolean isCriticalHit(Player attacker) {
        return attacker.getFallDistance() > 0f
                && !attacker.isOnGround()
                && !attacker.isInsideVehicle()
                && !attacker.hasPotionEffect(PotionEffectType.BLINDNESS)
                && !attacker.isSprinting();
    }

    // ================== FRECCIA CHE MANCA IL BERSAGLIO (interrompe la serie) ==================

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Arrow arrow)) return;
        if (event.getHitEntity() != null) return; // ha colpito un'entità, gestito altrove
        if (!(arrow.getShooter() instanceof Player shooter)) return;
        if (!isClass(shooter, PlayerClass.BOW)) return;

        abilityManager.resetBowStreak(shooter.getUniqueId());
        abilityManager.resetBowRainStreak(shooter.getUniqueId());
    }

    // ========== ARCIERE COLPITO (interrompe la serie "Pioggia di Frecce") ==========

    @EventHandler(priority = EventPriority.MONITOR)
    public void onArcherDamaged(EntityDamageEvent event) {
        if (event.isCancelled()) return;
        if (event.getFinalDamage() <= 0) return;
        if (!(event.getEntity() instanceof Player player)) return;
        if (!isClass(player, PlayerClass.BOW)) return;

        abilityManager.resetBowRainStreak(player.getUniqueId());
    }

    // ================== BLOCCO MOVIMENTO/VISUALE (ascia) ==================

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (abilityManager.isFrozen(event.getPlayer().getUniqueId())) {
            // Cancellare il movimento riporta il giocatore alla posizione/orientamento
            // precedenti, bloccando di fatto sia lo spostamento che la visuale.
            event.setCancelled(true);
        }
    }

    // ================== PULIZIA ALLA DISCONNESSIONE ==================

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        if (abilityManager.hasSavedOffhand(id)) {
            ItemStack saved = abilityManager.takeSavedOffhand(id);
            player.getInventory().setItemInOffHand(saved);
        }
        if (abilityManager.isShieldImmortalActive(id)) {
            player.setInvulnerable(false);
        }
        abilityManager.clearPlayer(id);
    }
}
