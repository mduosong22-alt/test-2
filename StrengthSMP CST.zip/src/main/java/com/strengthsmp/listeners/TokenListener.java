package com.strengthsmp.listeners;

import com.strengthsmp.StrengthSMPPlugin;
import com.strengthsmp.managers.PlayerClass;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class TokenListener implements Listener {

    private final StrengthSMPPlugin plugin;

    public TokenListener(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onUseToken(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!event.getAction().isRightClick()) return;

        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (item == null) return;

        if (plugin.getStrengthToken().isToken(item)) {
            useStrengthToken(event, player, item);
        } else if (plugin.getRerollToken().isToken(item)) {
            useRerollToken(event, player, item);
        }
    }

    private void useStrengthToken(PlayerInteractEvent event, Player player, ItemStack item) {
        event.setCancelled(true);

        int gain = plugin.getConfig().getInt("token.strength-gain", 1);
        plugin.getDataManager().addStrength(player, gain);

        item.setAmount(item.getAmount() - 1);

        String msg = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") +
                plugin.getConfig().getString("messages.token-used", ""))
                .replace("%amount%", String.valueOf(gain));
        player.sendMessage(msg);
    }

    private void useRerollToken(PlayerInteractEvent event, Player player, ItemStack item) {
        event.setCancelled(true);

        PlayerClass oldClass = plugin.getDataManager().getPlayerClass(player);
        PlayerClass newClass = plugin.getDataManager().rerollClass(player);

        item.setAmount(item.getAmount() - 1);

        String msg = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") +
                plugin.getConfig().getString("reroll-token.messages.used", ""))
                .replace("%old_class%", oldClass != null ? oldClass.getDisplayName() : "?")
                .replace("%new_class%", newClass.getColor() + newClass.getDisplayName());
        player.sendMessage(msg);
        player.sendTitle(newClass.getColor() + "" + ChatColor.BOLD + "Nuova classe: " + newClass.getDisplayName(), "", 0, 40, 10);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        player.getWorld().spawnParticle(org.bukkit.Particle.TOTEM_OF_UNDYING, player.getLocation().add(0, 1, 0), 40, 0.5, 1, 0.5, 0.1);
    }
}
