package com.strengthsmp.listeners;

import com.strengthsmp.StrengthSMPPlugin;
import com.strengthsmp.managers.PlayerClass;
import com.strengthsmp.managers.PlayerData;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class JoinQuitListener implements Listener {

    private final StrengthSMPPlugin plugin;

    public JoinQuitListener(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // Assicura che i dati esistano (assegna la classe casuale al primo ingresso)
        // e riapplica il moltiplicatore di danno da Strength.
        PlayerData data = plugin.getDataManager().getData(player);
        plugin.getDataManager().applyStrengthAttribute(player);

        if (plugin.getDataManager().consumeFreshlyAssignedClass(player.getUniqueId())) {
            announceNewClass(player, data.getWeaponClass());
        }
    }

    private void announceNewClass(Player player, PlayerClass playerClass) {
        String prefix = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", ""));

        String msg = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("class.messages.welcome", ""))
                .replace("%class%", playerClass.getColor() + playerClass.getDisplayName());
        player.sendMessage(prefix + msg);

        player.sendTitle(
                playerClass.getColor() + "" + ChatColor.BOLD + "Classe: " + playerClass.getDisplayName(),
                ChatColor.GRAY + "Puoi usare solo le abilità di quest'arma",
                10, 60, 20);
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getDataManager().saveAll();
    }
}
