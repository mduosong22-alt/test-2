package com.strengthsmp.listeners;

import io.papermc.paper.event.player.PlayerShieldDisableEvent;
import com.strengthsmp.StrengthSMPPlugin;
import com.strengthsmp.managers.PlayerClass;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

/**
 * Gestisce le meccaniche passive dello Scudo (classe SHIELD):
 *  - finché lo scudo è impugnato (mano principale o secondaria), il
 *    giocatore ha 2 cuori (4 HP) di vita massima in meno;
 *  - se un avversario disattiva lo scudo (PlayerShieldDisableEvent), il
 *    giocatore subisce metà danno per qualche secondo, come compensazione;
 * L'abilità di immortalità/lentezza è gestita in WeaponAbilityListener.
 */
public class ShieldListener implements Listener {

    private final StrengthSMPPlugin plugin;
    private static final String MODIFIER_NAME = "strengthsmp_shield_penalty";

    public ShieldListener(StrengthSMPPlugin plugin) {
        this.plugin = plugin;
        startPenaltyTask();
    }

    private boolean isClass(Player player, PlayerClass required) {
        return plugin.getDataManager().isClass(player, required);
    }

    private boolean holdingShield(Player player) {
        ItemStack main = player.getInventory().getItemInMainHand();
        ItemStack off = player.getInventory().getItemInOffHand();
        return main.getType() == Material.SHIELD || off.getType() == Material.SHIELD;
    }

    private void startPenaltyTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                double hearts = plugin.getConfig().getDouble("weapons.shield.equipped-hearts-penalty", 2);
                double penalty = hearts * 2.0; // 1 cuore = 2 HP

                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    boolean shouldApply = isClass(player, PlayerClass.SHIELD) && holdingShield(player);
                    applyOrRemovePenalty(player, shouldApply, penalty);
                }
            }
        }.runTaskTimer(plugin, 20L, 10L);
    }

    private void applyOrRemovePenalty(Player player, boolean shouldApply, double penalty) {
        AttributeInstance maxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHealth == null) return;

        boolean currentlyApplied = maxHealth.getModifiers().stream()
                .anyMatch(mod -> mod.getName().equals(MODIFIER_NAME));

        if (shouldApply && !currentlyApplied) {
            AttributeModifier modifier = new AttributeModifier(
                    UUID.nameUUIDFromBytes((MODIFIER_NAME + "_" + player.getUniqueId()).getBytes()),
                    MODIFIER_NAME,
                    -penalty,
                    AttributeModifier.Operation.ADD_NUMBER
            );
            maxHealth.addModifier(modifier);
            if (player.getHealth() > maxHealth.getValue()) {
                player.setHealth(Math.max(1.0, maxHealth.getValue()));
            }
        } else if (!shouldApply && currentlyApplied) {
            maxHealth.getModifiers().stream()
                    .filter(mod -> mod.getName().equals(MODIFIER_NAME))
                    .forEach(maxHealth::removeModifier);
        }
    }

    @EventHandler
    public void onShieldDisable(PlayerShieldDisableEvent event) {
        Player player = event.getPlayer();
        if (!isClass(player, PlayerClass.SHIELD)) return;

        long seconds = plugin.getConfig().getLong("weapons.shield.disable-half-damage-seconds", 8);
        plugin.getAbilityManager().setShieldHalfDamageUntil(player.getUniqueId(),
                System.currentTimeMillis() + seconds * 1000L);

        String msg = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") +
                plugin.getConfig().getString("weapons.shield.messages.disabled", ""))
                .replace("%seconds%", String.valueOf(seconds));
        player.sendMessage(msg);
        player.playSound(player.getLocation(), Sound.ITEM_SHIELD_BREAK, 1f, 1f);
    }
}
